#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <stdatomic.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <linux/futex.h>
#include <time.h>
#include <sched.h>

typedef enum {
  M_EVERY_INLINE,
  M_EVERY_LOCAL,
  M_EVERY_UNROLL4,
  M_EVERY_PREFETCH,
  M_EVERY_UNROLL8_PREFETCH,
  M_EVERY_SPEC8,
  M_EVERY_FAST4,
  M_EVERY_FAST8,
  M_EVERY_PIPE2,
  M_EVERY_PIPE3,
  M_EVERY_PIPE4,
  M_BASE_TRIPLE_COND,
  M_BASE_SEQ_SPIN,
  M_QUAD_CLAIM_COND,
  M_QUINT_CLAIM_COND,
  M_QUAD_CLAIM_HYBRID,
  M_RING8_SPIN,
  M_RING8_HYBRID,
  M_RING32_FUTEX,
  M_SLAB4_COND,
  M_SLAB5_COND,
  M_SLAB4_HYBRID,
  M_SLAB5_HYBRID,
  M_SLAB6_COND,
  M_SLAB6_HYBRID,
  M_SLAB4_SPIN,
  M_SLAB5_SPIN,
  M_SLAB6_SPIN,
  M_SLAB6_CHAIN_ZC,
  M_RING8_SEGMENTED,
  MODE_COUNT
} model_t;

typedef struct {
  int tx_fd, rx_fd;
  size_t frame_size, slab_bytes, frames_per_slab;
  int duration_ms, work_us;
  int hybrid_spins;
  int publish_stride;
  model_t mode;
  uint8_t *send_slab;
  _Atomic bool stop;
  _Atomic uint64_t input_frames, published_frames, producer_frames;
  _Atomic uint64_t socket_reads, socket_writes, validation_errors, retries, waits, wakes;

  // Every pipeline (bounded strict FIFO of complete-frame chunks)
  int pipe_n;
  uint8_t **pipe_buf;
  size_t *pipe_len;
  int *pipe_q;
  int pipe_qh, pipe_qt, pipe_qcount;
  bool pipe_done;
  pthread_mutex_t pipe_mu;
  pthread_cond_t pipe_not_empty, pipe_not_full;
  uint8_t *pipe_carry;
  size_t pipe_carry_len;

  // Frame-slot Latest models
  int fslot_n;
  uint8_t **fslots;
  int f_pending;
  int f_producer;
  int f_free[8];
  int f_free_count;
  int f_reading;
  bool latest_done;
  pthread_mutex_t f_mu;
  pthread_cond_t f_cv;
  uint8_t *consumer_buf;

  // Seqlock baseline / ring
  uint8_t *seq_slot;
  _Atomic uint64_t seq_generation;

  int ring_n;
  uint8_t **ring_slots;
  _Atomic uint64_t *ring_seq;
  _Atomic uint64_t ring_latest_ticket;
  _Atomic uint32_t ring_wake_seq;
  _Atomic int ring_waiting;

  // Slab-swap Latest
  int sslab_n;
  uint8_t **sslabs;
  size_t *sslab_last_off;
  int s_pending, s_producer, s_reading;
  int s_free[8], s_free_count;
  bool s_done;
  pthread_mutex_t s_mu;
  pthread_cond_t s_cv;
  uint8_t *s_carry;
  size_t s_carry_len;
} ctx_t;

static inline uint64_t ns_now(clockid_t clk){ struct timespec ts; clock_gettime(clk,&ts); return (uint64_t)ts.tv_sec*1000000000ull+ts.tv_nsec; }
static inline void cpu_relax(void){ __asm__ __volatile__("pause" ::: "memory"); }
static void pin_cpu(int cpu){ cpu_set_t set; CPU_ZERO(&set); CPU_SET(cpu,&set); pthread_setaffinity_np(pthread_self(),sizeof(set),&set); }
static void busy_work_us(int us){ if(us<=0)return; uint64_t end=ns_now(CLOCK_MONOTONIC)+(uint64_t)us*1000ull; while(ns_now(CLOCK_MONOTONIC)<end) cpu_relax(); }
static size_t adaptive_slab(size_t f){ size_t v=f*512ull; if(v<16384)v=16384; if(v>1048576)v=1048576; v-=v%f; return v<f?f:v; }
static int futex_wait32(_Atomic uint32_t *p,uint32_t v){ return syscall(SYS_futex,(uint32_t*)p,FUTEX_WAIT_PRIVATE,v,NULL,NULL,0); }
static int futex_wake32(_Atomic uint32_t *p){ return syscall(SYS_futex,(uint32_t*)p,FUTEX_WAKE_PRIVATE,1,NULL,NULL,0); }

static void fill_slab(ctx_t*c){
  for(size_t i=0;i<c->frames_per_slab;i++){
    uint8_t*p=c->send_slab+i*c->frame_size; uint64_t id=i; memcpy(p,&id,8); uint8_t pat=id&255;
    for(size_t j=8;j<c->frame_size;j++) p[j]=pat;
  }
}
static bool validate_frame(const ctx_t*c,const uint8_t*p){
  uint64_t id; memcpy(&id,p,8); if(id>=c->frames_per_slab)return false; uint8_t pat=id&255;
  if(c->frame_size>8 && p[8]!=pat)return false;
  if(c->frame_size>16 && p[c->frame_size/2]!=pat)return false;
  if(c->frame_size>9 && p[c->frame_size-1]!=pat)return false;
  return true;
}
static inline void process_frame(ctx_t*c,const uint8_t*p){
  if(!validate_frame(c,p)) atomic_fetch_add_explicit(&c->validation_errors,1,memory_order_relaxed);
  busy_work_us(c->work_us);
  atomic_fetch_add_explicit(&c->published_frames,1,memory_order_relaxed);
}

static void *producer_thread(void*arg){
  ctx_t*c=arg; pin_cpu(0);
  while(!atomic_load_explicit(&c->stop,memory_order_relaxed)){
    size_t off=0;
    while(off<c->slab_bytes){
      ssize_t n=send(c->tx_fd,c->send_slab+off,c->slab_bytes-off,MSG_NOSIGNAL);
      if(n<0){ if(errno==EINTR)continue; goto done; }
      if(!n)goto done;
      off+=(size_t)n; atomic_fetch_add_explicit(&c->socket_writes,1,memory_order_relaxed);
    }
    atomic_fetch_add_explicit(&c->producer_frames,c->frames_per_slab,memory_order_relaxed);
  }
done: shutdown(c->tx_fd,SHUT_WR); return NULL;
}

// ---------- strict Every ----------

static inline bool process_frame_local(ctx_t*c,const uint8_t*p){
  bool ok=validate_frame(c,p);
  busy_work_us(c->work_us);
  return ok;
}
static void every_local_receiver(ctx_t*c,int flavor){
  uint8_t *buf=aligned_alloc(64,(c->slab_bytes+c->frame_size+63)&~63ull); size_t carry=0; uint64_t pubs=0,errs=0,inputs=0,reads=0;
  for(;;){
    ssize_t n=recv(c->rx_fd,buf+carry,c->slab_bytes-carry,0); if(n<0){if(errno==EINTR)continue;break;} if(!n)break; reads++;
    size_t total=carry+(size_t)n, full=total/c->frame_size, used=full*c->frame_size; inputs+=full;
    if(flavor==1){
      size_t i=0; for(;i+4<=full;i+=4){
        errs+=!process_frame_local(c,buf+(i+0)*c->frame_size);
        errs+=!process_frame_local(c,buf+(i+1)*c->frame_size);
        errs+=!process_frame_local(c,buf+(i+2)*c->frame_size);
        errs+=!process_frame_local(c,buf+(i+3)*c->frame_size); pubs+=4;
      }
      for(;i<full;i++){errs+=!process_frame_local(c,buf+i*c->frame_size);pubs++;}
    } else if(flavor==2){
      for(size_t i=0;i<full;i++){ if(i+8<full)__builtin_prefetch(buf+(i+8)*c->frame_size,0,1); errs+=!process_frame_local(c,buf+i*c->frame_size);pubs++; }
    } else if(flavor==3){
      size_t i=0; for(;i+8<=full;i+=8){
        if(i+16<full)__builtin_prefetch(buf+(i+16)*c->frame_size,0,1);
        errs+=!process_frame_local(c,buf+(i+0)*c->frame_size); errs+=!process_frame_local(c,buf+(i+1)*c->frame_size);
        errs+=!process_frame_local(c,buf+(i+2)*c->frame_size); errs+=!process_frame_local(c,buf+(i+3)*c->frame_size);
        errs+=!process_frame_local(c,buf+(i+4)*c->frame_size); errs+=!process_frame_local(c,buf+(i+5)*c->frame_size);
        errs+=!process_frame_local(c,buf+(i+6)*c->frame_size); errs+=!process_frame_local(c,buf+(i+7)*c->frame_size); pubs+=8;
      }
      for(;i<full;i++){errs+=!process_frame_local(c,buf+i*c->frame_size);pubs++;}
    } else if(flavor==4 && c->frame_size==32){
      size_t i=0; for(;i+8<=full;i+=8){
        if(i+16<full)__builtin_prefetch(buf+(i+16)*32,0,1);
        for(int k=0;k<8;k++){ const uint8_t*p=buf+(i+k)*32; uint64_t id; memcpy(&id,p,8); uint8_t pat=id&255; errs += (id>=c->frames_per_slab || p[8]!=pat || p[16]!=pat || p[31]!=pat); } pubs+=8;
      }
      for(;i<full;i++){ const uint8_t*p=buf+i*32; uint64_t id; memcpy(&id,p,8); uint8_t pat=id&255; errs += (id>=c->frames_per_slab || p[8]!=pat || p[16]!=pat || p[31]!=pat); pubs++; }
    } else if(flavor==5 && c->work_us==0){
      size_t i=0; for(;i+4<=full;i+=4){
        errs+=!validate_frame(c,buf+(i+0)*c->frame_size); errs+=!validate_frame(c,buf+(i+1)*c->frame_size);
        errs+=!validate_frame(c,buf+(i+2)*c->frame_size); errs+=!validate_frame(c,buf+(i+3)*c->frame_size); pubs+=4;
      } for(;i<full;i++){errs+=!validate_frame(c,buf+i*c->frame_size);pubs++;}
    } else if(flavor==6 && c->work_us==0){
      size_t i=0; for(;i+8<=full;i+=8){
        if(i+16<full)__builtin_prefetch(buf+(i+16)*c->frame_size,0,1);
        errs+=!validate_frame(c,buf+(i+0)*c->frame_size); errs+=!validate_frame(c,buf+(i+1)*c->frame_size);
        errs+=!validate_frame(c,buf+(i+2)*c->frame_size); errs+=!validate_frame(c,buf+(i+3)*c->frame_size);
        errs+=!validate_frame(c,buf+(i+4)*c->frame_size); errs+=!validate_frame(c,buf+(i+5)*c->frame_size);
        errs+=!validate_frame(c,buf+(i+6)*c->frame_size); errs+=!validate_frame(c,buf+(i+7)*c->frame_size); pubs+=8;
      } for(;i<full;i++){errs+=!validate_frame(c,buf+i*c->frame_size);pubs++;}
    } else {
      for(size_t i=0;i<full;i++){errs+=!process_frame_local(c,buf+i*c->frame_size);pubs++;}
    }
    carry=total-used; if(carry)memmove(buf,buf+used,carry);
  }
  atomic_fetch_add(&c->socket_reads,reads); atomic_fetch_add(&c->input_frames,inputs); atomic_fetch_add(&c->published_frames,pubs); atomic_fetch_add(&c->validation_errors,errs); free(buf);
}
static void every_inline_receiver(ctx_t*c){
  uint8_t *buf=aligned_alloc(64,(c->slab_bytes+c->frame_size+63)&~63ull); size_t carry=0;
  for(;;){
    ssize_t n=recv(c->rx_fd,buf+carry,c->slab_bytes-carry,0); if(n<0){if(errno==EINTR)continue;break;} if(!n)break;
    atomic_fetch_add(&c->socket_reads,1); size_t total=carry+(size_t)n, full=total/c->frame_size, used=full*c->frame_size;
    atomic_fetch_add(&c->input_frames,full);
    for(size_t i=0;i<full;i++) process_frame(c,buf+i*c->frame_size);
    carry=total-used; if(carry)memmove(buf,buf+used,carry);
  }
  free(buf);
}

static int pipe_get_free_locked(ctx_t*c){
  // free slots are those not in queue; simplest: scan q membership using len==SIZE_MAX marker
  for(int i=0;i<c->pipe_n;i++) if(c->pipe_len[i]==(size_t)-1) return i;
  return -1;
}
static void every_pipe_receiver(ctx_t*c){
  size_t carry=0;
  for(;;){
    pthread_mutex_lock(&c->pipe_mu);
    int idx;
    while((idx=pipe_get_free_locked(c))<0) pthread_cond_wait(&c->pipe_not_full,&c->pipe_mu);
    c->pipe_len[idx]=0; // reserve
    pthread_mutex_unlock(&c->pipe_mu);
    uint8_t *buf=c->pipe_buf[idx];
    if(carry) memcpy(buf,c->pipe_carry,carry);
    ssize_t n;
    do { n=recv(c->rx_fd,buf+carry,c->slab_bytes-carry,0); } while(n<0&&errno==EINTR);
    if(n<=0){
      pthread_mutex_lock(&c->pipe_mu); c->pipe_len[idx]=(size_t)-1; c->pipe_done=true; pthread_cond_broadcast(&c->pipe_not_empty); pthread_mutex_unlock(&c->pipe_mu); break;
    }
    atomic_fetch_add(&c->socket_reads,1);
    size_t total=carry+(size_t)n, full=total/c->frame_size, used=full*c->frame_size;
    carry=total-used; if(carry)memcpy(c->pipe_carry,buf+used,carry);
    if(!full){ pthread_mutex_lock(&c->pipe_mu); c->pipe_len[idx]=(size_t)-1; pthread_cond_signal(&c->pipe_not_full); pthread_mutex_unlock(&c->pipe_mu); continue; }
    atomic_fetch_add(&c->input_frames,full);
    pthread_mutex_lock(&c->pipe_mu);
    c->pipe_len[idx]=used; c->pipe_q[c->pipe_qt]=idx; c->pipe_qt=(c->pipe_qt+1)%c->pipe_n; c->pipe_qcount++;
    pthread_cond_signal(&c->pipe_not_empty); pthread_mutex_unlock(&c->pipe_mu);
  }
}
static void *every_pipe_consumer(void*arg){
  ctx_t*c=arg; pin_cpu(2);
  for(;;){
    pthread_mutex_lock(&c->pipe_mu);
    while(c->pipe_qcount==0&&!c->pipe_done) pthread_cond_wait(&c->pipe_not_empty,&c->pipe_mu);
    if(c->pipe_qcount==0&&c->pipe_done){pthread_mutex_unlock(&c->pipe_mu);break;}
    int idx=c->pipe_q[c->pipe_qh]; c->pipe_qh=(c->pipe_qh+1)%c->pipe_n; c->pipe_qcount--; size_t len=c->pipe_len[idx];
    pthread_mutex_unlock(&c->pipe_mu);
    size_t full=len/c->frame_size; uint8_t*b=c->pipe_buf[idx];
    for(size_t i=0;i<full;i++) process_frame(c,b+i*c->frame_size);
    pthread_mutex_lock(&c->pipe_mu); c->pipe_len[idx]=(size_t)-1; pthread_cond_signal(&c->pipe_not_full); pthread_mutex_unlock(&c->pipe_mu);
  }
  return NULL;
}

// ---------- frame-slot Latest ----------
static void f_init_free(ctx_t*c,int n){ c->fslot_n=n; c->f_pending=-1; c->f_reading=-1; c->f_producer=0; c->f_free_count=0; for(int i=1;i<n;i++)c->f_free[c->f_free_count++]=i; }
static int f_pop_free(ctx_t*c){ return c->f_free_count?c->f_free[--c->f_free_count]:-1; }
static void f_push_free(ctx_t*c,int x){ if(x>=0)c->f_free[c->f_free_count++]=x; }
static void frame_publish_baseline(ctx_t*c,const uint8_t*f){
  int w=c->f_producer; memcpy(c->fslots[w],f,c->frame_size);
  pthread_mutex_lock(&c->f_mu); int old=c->f_pending; c->f_pending=w;
  if(old>=0)c->f_producer=old; else c->f_producer=f_pop_free(c);
  if(old<0){pthread_cond_signal(&c->f_cv);atomic_fetch_add(&c->wakes,1);} pthread_mutex_unlock(&c->f_mu);
  while(c->f_producer<0){ pthread_mutex_lock(&c->f_mu); c->f_producer=f_pop_free(c); pthread_mutex_unlock(&c->f_mu); if(c->f_producer<0){atomic_fetch_add(&c->waits,1);sched_yield();} }
}
static void frame_publish_claim(ctx_t*c,const uint8_t*f){
  int w=c->f_producer; memcpy(c->fslots[w],f,c->frame_size); // producer-owned
  pthread_mutex_lock(&c->f_mu); int old=c->f_pending; c->f_pending=w;
  if(old>=0){c->f_producer=old;} else {c->f_producer=f_pop_free(c); pthread_cond_signal(&c->f_cv); atomic_fetch_add(&c->wakes,1);} pthread_mutex_unlock(&c->f_mu);
  while(c->f_producer<0){ pthread_mutex_lock(&c->f_mu); c->f_producer=f_pop_free(c); pthread_mutex_unlock(&c->f_mu); if(c->f_producer<0){atomic_fetch_add(&c->waits,1);cpu_relax();} }
}
static bool frame_claim_take(ctx_t*c,bool process){
  pthread_mutex_lock(&c->f_mu); int idx=c->f_pending; if(idx<0){pthread_mutex_unlock(&c->f_mu);return false;} c->f_pending=-1; c->f_reading=idx; pthread_mutex_unlock(&c->f_mu);
  memcpy(c->consumer_buf,c->fslots[idx],c->frame_size); // outside lock
  pthread_mutex_lock(&c->f_mu); c->f_reading=-1; f_push_free(c,idx); pthread_mutex_unlock(&c->f_mu);
  if(process)process_frame(c,c->consumer_buf); return true;
}
static void *frame_cond_consumer(void*arg){
  ctx_t*c=arg; pin_cpu(2);
  for(;;){
    pthread_mutex_lock(&c->f_mu); while(c->f_pending<0&&!c->latest_done)pthread_cond_wait(&c->f_cv,&c->f_mu); bool done=(c->f_pending<0&&c->latest_done); pthread_mutex_unlock(&c->f_mu); if(done)break;
    frame_claim_take(c,true);
  }
  return NULL;
}
static void *frame_hybrid_consumer(void*arg){
  ctx_t*c=arg; pin_cpu(2); int idle=0;
  for(;;){
    if(frame_claim_take(c,true)){idle=0;continue;}
    pthread_mutex_lock(&c->f_mu); bool done=c->latest_done; pthread_mutex_unlock(&c->f_mu); if(done)break;
    if(idle++<c->hybrid_spins)cpu_relax(); else {pthread_mutex_lock(&c->f_mu); if(c->f_pending<0&&!c->latest_done)pthread_cond_wait(&c->f_cv,&c->f_mu); pthread_mutex_unlock(&c->f_mu); idle=0;}
  }
  return NULL;
}

// ---------- seqlock baseline ----------
static void seq_publish(ctx_t*c,const uint8_t*f){ uint64_t g=atomic_load(&c->seq_generation); if(g&1)g++; atomic_store_explicit(&c->seq_generation,g+1,memory_order_release); memcpy(c->seq_slot,f,c->frame_size); atomic_store_explicit(&c->seq_generation,g+2,memory_order_release); }
static void *seq_consumer(void*arg){ctx_t*c=arg;pin_cpu(2);uint64_t last=0;for(;;){uint64_t g1=atomic_load_explicit(&c->seq_generation,memory_order_acquire);if((g1&1)||!g1||g1==last){if(c->latest_done&&g1==last)break;cpu_relax();continue;}memcpy(c->consumer_buf,c->seq_slot,c->frame_size);uint64_t g2=atomic_load_explicit(&c->seq_generation,memory_order_acquire);if(g1!=g2||(g2&1)){atomic_fetch_add(&c->retries,1);continue;}last=g2;process_frame(c,c->consumer_buf);}return NULL;}

// ---------- generation ring Latest ----------
static void ring_publish(ctx_t*c,const uint8_t*f){
  uint64_t t=atomic_load_explicit(&c->ring_latest_ticket,memory_order_relaxed)+1; int idx=(int)(t%(uint64_t)c->ring_n);
  uint64_t odd=t*2+1, even=t*2+2; atomic_store_explicit(&c->ring_seq[idx],odd,memory_order_release); memcpy(c->ring_slots[idx],f,c->frame_size); atomic_store_explicit(&c->ring_seq[idx],even,memory_order_release); atomic_store_explicit(&c->ring_latest_ticket,t,memory_order_release);
  atomic_fetch_add_explicit(&c->ring_wake_seq,1,memory_order_release);
  if(atomic_exchange_explicit(&c->ring_waiting,0,memory_order_acq_rel)){futex_wake32(&c->ring_wake_seq);atomic_fetch_add(&c->wakes,1);} }
static bool ring_take(ctx_t*c,uint64_t*last){
  uint64_t t=atomic_load_explicit(&c->ring_latest_ticket,memory_order_acquire); if(!t||t==*last)return false; int idx=(int)(t%(uint64_t)c->ring_n); uint64_t s1=atomic_load_explicit(&c->ring_seq[idx],memory_order_acquire); if(s1&1){atomic_fetch_add(&c->retries,1);return false;} memcpy(c->consumer_buf,c->ring_slots[idx],c->frame_size); uint64_t s2=atomic_load_explicit(&c->ring_seq[idx],memory_order_acquire); uint64_t t2=atomic_load_explicit(&c->ring_latest_ticket,memory_order_acquire); if(s1!=s2||(s2&1)||t2<t){atomic_fetch_add(&c->retries,1);return false;} *last=t; process_frame(c,c->consumer_buf); return true; }
static void *ring_spin_consumer(void*arg){ctx_t*c=arg;pin_cpu(2);uint64_t last=0;for(;;){if(ring_take(c,&last))continue;if(c->latest_done&&atomic_load(&c->ring_latest_ticket)==last)break;cpu_relax();}return NULL;}
static void *ring_hybrid_consumer(void*arg){ctx_t*c=arg;pin_cpu(2);uint64_t last=0;int idle=0;for(;;){if(ring_take(c,&last)){idle=0;continue;}if(c->latest_done&&atomic_load(&c->ring_latest_ticket)==last)break;if(idle++<c->hybrid_spins){cpu_relax();continue;}uint32_t seq=atomic_load_explicit(&c->ring_wake_seq,memory_order_acquire);atomic_store_explicit(&c->ring_waiting,1,memory_order_release);if(atomic_load_explicit(&c->ring_latest_ticket,memory_order_acquire)!=last){atomic_store(&c->ring_waiting,0);idle=0;continue;}futex_wait32(&c->ring_wake_seq,seq);atomic_store(&c->ring_waiting,0);idle=0;}return NULL;}
static void *ring_futex_consumer(void*arg){ctx_t*c=arg;pin_cpu(2);uint64_t last=0;for(;;){while(ring_take(c,&last)){}if(c->latest_done&&atomic_load(&c->ring_latest_ticket)==last)break;uint32_t seq=atomic_load_explicit(&c->ring_wake_seq,memory_order_acquire);atomic_store_explicit(&c->ring_waiting,1,memory_order_release);if(atomic_load_explicit(&c->ring_latest_ticket,memory_order_acquire)!=last){atomic_store(&c->ring_waiting,0);continue;}futex_wait32(&c->ring_wake_seq,seq);atomic_store(&c->ring_waiting,0);}return NULL;}

// ---------- slab-swap Latest ----------
static void s_init(ctx_t*c,int n){c->sslab_n=n;c->s_pending=-1;c->s_reading=-1;c->s_producer=0;c->s_free_count=0;for(int i=1;i<n;i++)c->s_free[c->s_free_count++]=i;}
static int s_pop(ctx_t*c){return c->s_free_count?c->s_free[--c->s_free_count]:-1;}static void s_push(ctx_t*c,int i){if(i>=0)c->s_free[c->s_free_count++]=i;}
static void *slab_cond_consumer(void*arg){ctx_t*c=arg;pin_cpu(2);for(;;){pthread_mutex_lock(&c->s_mu);while(c->s_pending<0&&!c->s_done)pthread_cond_wait(&c->s_cv,&c->s_mu);if(c->s_pending<0&&c->s_done){pthread_mutex_unlock(&c->s_mu);break;}int idx=c->s_pending;c->s_pending=-1;c->s_reading=idx;size_t off=c->sslab_last_off[idx];pthread_mutex_unlock(&c->s_mu);memcpy(c->consumer_buf,c->sslabs[idx]+off,c->frame_size);pthread_mutex_lock(&c->s_mu);c->s_reading=-1;s_push(c,idx);pthread_mutex_unlock(&c->s_mu);process_frame(c,c->consumer_buf);}return NULL;}
static bool slab_take_once(ctx_t*c){pthread_mutex_lock(&c->s_mu);int idx=c->s_pending;if(idx<0){pthread_mutex_unlock(&c->s_mu);return false;}c->s_pending=-1;c->s_reading=idx;size_t off=c->sslab_last_off[idx];pthread_mutex_unlock(&c->s_mu);memcpy(c->consumer_buf,c->sslabs[idx]+off,c->frame_size);pthread_mutex_lock(&c->s_mu);c->s_reading=-1;s_push(c,idx);pthread_mutex_unlock(&c->s_mu);process_frame(c,c->consumer_buf);return true;}
static void *slab_hybrid_consumer(void*arg){ctx_t*c=arg;pin_cpu(2);int idle=0;for(;;){if(slab_take_once(c)){idle=0;continue;}pthread_mutex_lock(&c->s_mu);bool done=c->s_done;pthread_mutex_unlock(&c->s_mu);if(done)break;if(idle++<c->hybrid_spins)cpu_relax();else{pthread_mutex_lock(&c->s_mu);if(c->s_pending<0&&!c->s_done)pthread_cond_wait(&c->s_cv,&c->s_mu);pthread_mutex_unlock(&c->s_mu);idle=0;}}return NULL;}
static void *slab_spin_consumer(void*arg){ctx_t*c=arg;pin_cpu(2);for(;;){if(slab_take_once(c))continue;pthread_mutex_lock(&c->s_mu);bool done=c->s_done;pthread_mutex_unlock(&c->s_mu);if(done)break;cpu_relax();}return NULL;}

static void *slab_chain_zc_consumer(void*arg){
  ctx_t*c=arg; pin_cpu(2); int held=-1;
  for(;;){
    pthread_mutex_lock(&c->s_mu);
    if(held>=0){ c->s_reading=-1; s_push(c,held); held=-1; }
    while(c->s_pending<0&&!c->s_done) pthread_cond_wait(&c->s_cv,&c->s_mu);
    if(c->s_pending<0&&c->s_done){ pthread_mutex_unlock(&c->s_mu); break; }
    int idx=c->s_pending; c->s_pending=-1; c->s_reading=idx; size_t off=c->sslab_last_off[idx]; held=idx;
    pthread_mutex_unlock(&c->s_mu);
    process_frame(c,c->sslabs[idx]+off);
  }
  if(held>=0){ pthread_mutex_lock(&c->s_mu); c->s_reading=-1; s_push(c,held); pthread_mutex_unlock(&c->s_mu); }
  return NULL;
}
static void slab_swap_receiver(ctx_t*c){
  size_t carry=0;
  for(;;){
    int p=c->s_producer;
    if(carry)memcpy(c->sslabs[p],c->s_carry,carry);
    ssize_t n; do{n=recv(c->rx_fd,c->sslabs[p]+carry,c->slab_bytes-carry,0);}while(n<0&&errno==EINTR);
    if(n<=0)break; atomic_fetch_add(&c->socket_reads,1); size_t total=carry+(size_t)n,full=total/c->frame_size,used=full*c->frame_size; carry=total-used;if(carry)memcpy(c->s_carry,c->sslabs[p]+used,carry);if(!full)continue;atomic_fetch_add(&c->input_frames,full);c->sslab_last_off[p]=(full-1)*c->frame_size;
    pthread_mutex_lock(&c->s_mu);int old=c->s_pending;c->s_pending=p;if(old>=0)c->s_producer=old;else{c->s_producer=s_pop(c);pthread_cond_signal(&c->s_cv);atomic_fetch_add(&c->wakes,1);}pthread_mutex_unlock(&c->s_mu);
    while(c->s_producer<0){pthread_mutex_lock(&c->s_mu);c->s_producer=s_pop(c);pthread_mutex_unlock(&c->s_mu);if(c->s_producer<0){atomic_fetch_add(&c->waits,1);cpu_relax();}}
  }
  pthread_mutex_lock(&c->s_mu);c->s_done=true;pthread_cond_broadcast(&c->s_cv);pthread_mutex_unlock(&c->s_mu);
}

static void latest_frame_receiver(ctx_t*c){
  uint8_t*buf=aligned_alloc(64,(c->slab_bytes+c->frame_size+63)&~63ull); size_t carry=0;
  for(;;){
    ssize_t n=recv(c->rx_fd,buf+carry,c->slab_bytes-carry,0);
    if(n<0){if(errno==EINTR)continue;break;} if(!n)break;
    atomic_fetch_add(&c->socket_reads,1);
    size_t total=carry+(size_t)n, full=total/c->frame_size, used=full*c->frame_size;
    if(full){
      atomic_fetch_add(&c->input_frames,full);
      if(c->mode==M_RING8_SEGMENTED){
        size_t stride=(size_t)c->publish_stride;
        size_t last_pub=(size_t)-1;
        for(size_t i=stride-1;i<full;i+=stride){ ring_publish(c,buf+i*c->frame_size); last_pub=i; if(full-i<=stride) break; }
        if(last_pub!=full-1) ring_publish(c,buf+(full-1)*c->frame_size);
      }else{
        const uint8_t*last=buf+(full-1)*c->frame_size;
        switch(c->mode){
          case M_BASE_TRIPLE_COND:frame_publish_baseline(c,last);break;
          case M_QUAD_CLAIM_COND:case M_QUINT_CLAIM_COND:case M_QUAD_CLAIM_HYBRID:frame_publish_claim(c,last);break;
          case M_BASE_SEQ_SPIN:seq_publish(c,last);break;
          case M_RING8_SPIN:case M_RING8_HYBRID:case M_RING32_FUTEX:ring_publish(c,last);break;
          default:break;
        }
      }
    }
    carry=total-used; if(carry)memmove(buf,buf+used,carry);
  }
  free(buf); c->latest_done=true;
  pthread_mutex_lock(&c->f_mu);pthread_cond_broadcast(&c->f_cv);pthread_mutex_unlock(&c->f_mu);
  atomic_fetch_add(&c->ring_wake_seq,1);futex_wake32(&c->ring_wake_seq);
}
static void *receiver_thread(void*arg){ctx_t*c=arg;pin_cpu(1);switch(c->mode){case M_EVERY_INLINE:every_inline_receiver(c);break;case M_EVERY_LOCAL:every_local_receiver(c,0);break;case M_EVERY_UNROLL4:every_local_receiver(c,1);break;case M_EVERY_PREFETCH:every_local_receiver(c,2);break;case M_EVERY_UNROLL8_PREFETCH:every_local_receiver(c,3);break;case M_EVERY_SPEC8:every_local_receiver(c,4);break;case M_EVERY_FAST4:every_local_receiver(c,5);break;case M_EVERY_FAST8:every_local_receiver(c,6);break;case M_EVERY_PIPE2:case M_EVERY_PIPE3:case M_EVERY_PIPE4:every_pipe_receiver(c);break;case M_SLAB4_COND:case M_SLAB5_COND:case M_SLAB4_HYBRID:case M_SLAB5_HYBRID:case M_SLAB6_COND:case M_SLAB6_HYBRID:case M_SLAB4_SPIN:case M_SLAB5_SPIN:case M_SLAB6_SPIN:case M_SLAB6_CHAIN_ZC:slab_swap_receiver(c);break;default:latest_frame_receiver(c);break;}return NULL;}

static const char* mode_name(model_t m){switch(m){
case M_EVERY_INLINE:return"every-inline-baseline";case M_EVERY_LOCAL:return"every-local";case M_EVERY_UNROLL4:return"every-unroll4";case M_EVERY_PREFETCH:return"every-prefetch";case M_EVERY_UNROLL8_PREFETCH:return"every-unroll8-prefetch";case M_EVERY_SPEC8:return"every-spec8";case M_EVERY_FAST4:return"every-fast4";case M_EVERY_FAST8:return"every-fast8";case M_EVERY_PIPE2:return"every-pipe2";case M_EVERY_PIPE3:return"every-pipe3";case M_EVERY_PIPE4:return"every-pipe4";case M_BASE_TRIPLE_COND:return"latest-triple-cond-baseline";case M_BASE_SEQ_SPIN:return"latest-seqlock-spin-baseline";case M_QUAD_CLAIM_COND:return"latest-quad-claim-cond";case M_QUINT_CLAIM_COND:return"latest-quint-claim-cond";case M_QUAD_CLAIM_HYBRID:return"latest-quad-claim-hybrid";case M_RING8_SPIN:return"latest-ring8-spin";case M_RING8_HYBRID:return"latest-ring8-hybrid";case M_RING32_FUTEX:return"latest-ring32-futex";case M_SLAB4_COND:return"latest-slab4-cond";case M_SLAB5_COND:return"latest-slab5-cond";case M_SLAB4_HYBRID:return"latest-slab4-hybrid";case M_SLAB5_HYBRID:return"latest-slab5-hybrid";case M_SLAB6_COND:return"latest-slab6-cond";case M_SLAB6_HYBRID:return"latest-slab6-hybrid";case M_SLAB4_SPIN:return"latest-slab4-spin";case M_SLAB5_SPIN:return"latest-slab5-spin";case M_SLAB6_SPIN:return"latest-slab6-spin";case M_SLAB6_CHAIN_ZC:return"latest-slab6-chain-zc";case M_RING8_SEGMENTED:return"latest-ring8-segmented";default:return"?";}}
static int parse_mode(const char*s,model_t*out){for(int i=0;i<MODE_COUNT;i++)if(!strcmp(s,mode_name((model_t)i))){*out=(model_t)i;return 0;}return-1;}

static int run_one(model_t mode,size_t frame,int dur,int work,bool header){
  ctx_t c;memset(&c,0,sizeof(c));c.mode=mode;c.frame_size=frame;c.slab_bytes=adaptive_slab(frame);c.frames_per_slab=c.slab_bytes/frame;c.duration_ms=dur;c.work_us=work;const char*hs=getenv("DHMP_HYBRID_SPINS");c.hybrid_spins=hs?atoi(hs):128;const char*ps=getenv("DHMP_PUBLISH_STRIDE");c.publish_stride=ps?atoi(ps):64;if(c.publish_stride<1)c.publish_stride=1;c.f_pending=-1;c.s_pending=-1;c.f_reading=-1;c.s_reading=-1;
  pin_cpu(4);
  int sv[2];if(socketpair(AF_UNIX,SOCK_STREAM,0,sv)){perror("socketpair");return 1;}c.tx_fd=sv[0];c.rx_fd=sv[1];int bs=4*1024*1024;setsockopt(c.tx_fd,SOL_SOCKET,SO_SNDBUF,&bs,sizeof(bs));setsockopt(c.rx_fd,SOL_SOCKET,SO_RCVBUF,&bs,sizeof(bs));
  size_t sa=(c.slab_bytes+63)&~63ull,fa=(frame+63)&~63ull;c.send_slab=aligned_alloc(64,sa);c.consumer_buf=aligned_alloc(64,fa);c.seq_slot=aligned_alloc(64,fa);memset(c.consumer_buf,0,frame);memset(c.seq_slot,0,frame);fill_slab(&c);
  pthread_mutex_init(&c.pipe_mu,NULL);pthread_cond_init(&c.pipe_not_empty,NULL);pthread_cond_init(&c.pipe_not_full,NULL);pthread_mutex_init(&c.f_mu,NULL);pthread_cond_init(&c.f_cv,NULL);pthread_mutex_init(&c.s_mu,NULL);pthread_cond_init(&c.s_cv,NULL);

  // mode-specific allocations
  if(mode>=M_EVERY_PIPE2&&mode<=M_EVERY_PIPE4){c.pipe_n=mode==M_EVERY_PIPE2?2:mode==M_EVERY_PIPE3?3:4;c.pipe_buf=calloc(c.pipe_n,sizeof(void*));c.pipe_len=calloc(c.pipe_n,sizeof(size_t));c.pipe_q=calloc(c.pipe_n,sizeof(int));c.pipe_carry=aligned_alloc(64,fa);for(int i=0;i<c.pipe_n;i++){c.pipe_buf[i]=aligned_alloc(64,sa);c.pipe_len[i]=(size_t)-1;}}
  if(mode==M_BASE_TRIPLE_COND||mode==M_QUAD_CLAIM_COND||mode==M_QUINT_CLAIM_COND||mode==M_QUAD_CLAIM_HYBRID){int n=mode==M_BASE_TRIPLE_COND?3:mode==M_QUINT_CLAIM_COND?5:4;c.fslots=calloc(n,sizeof(void*));for(int i=0;i<n;i++)c.fslots[i]=aligned_alloc(64,fa);f_init_free(&c,n);}
  if(mode==M_RING8_SPIN||mode==M_RING8_HYBRID||mode==M_RING32_FUTEX||mode==M_RING8_SEGMENTED){const char*rs=getenv("DHMP_RING_SLOTS");int n=rs?atoi(rs):(mode==M_RING32_FUTEX?32:8);if(n<3)n=3;if(n>64)n=64;c.ring_n=n;c.ring_slots=calloc(n,sizeof(void*));c.ring_seq=calloc(n,sizeof(_Atomic uint64_t));for(int i=0;i<n;i++)c.ring_slots[i]=aligned_alloc(64,fa);}
  if(mode==M_SLAB4_COND||mode==M_SLAB5_COND||mode==M_SLAB4_HYBRID||mode==M_SLAB5_HYBRID||mode==M_SLAB6_COND||mode==M_SLAB6_HYBRID||mode==M_SLAB4_SPIN||mode==M_SLAB5_SPIN||mode==M_SLAB6_SPIN||mode==M_SLAB6_CHAIN_ZC){int n=(mode==M_SLAB5_COND||mode==M_SLAB5_HYBRID||mode==M_SLAB5_SPIN)?5:((mode==M_SLAB6_COND||mode==M_SLAB6_HYBRID||mode==M_SLAB6_SPIN||mode==M_SLAB6_CHAIN_ZC)?6:4);c.sslabs=calloc(n,sizeof(void*));c.sslab_last_off=calloc(n,sizeof(size_t));c.s_carry=aligned_alloc(64,fa);for(int i=0;i<n;i++)c.sslabs[i]=aligned_alloc(64,sa);s_init(&c,n);}

  pthread_t prod,recvth,cons;bool has_cons=false;void*(*cf)(void*)=NULL;
  switch(mode){case M_EVERY_PIPE2:case M_EVERY_PIPE3:case M_EVERY_PIPE4:has_cons=true;cf=every_pipe_consumer;break;case M_BASE_TRIPLE_COND:case M_QUAD_CLAIM_COND:case M_QUINT_CLAIM_COND:has_cons=true;cf=frame_cond_consumer;break;case M_QUAD_CLAIM_HYBRID:has_cons=true;cf=frame_hybrid_consumer;break;case M_BASE_SEQ_SPIN:has_cons=true;cf=seq_consumer;break;case M_RING8_SPIN:case M_RING8_SEGMENTED:has_cons=true;cf=ring_spin_consumer;break;case M_RING8_HYBRID:has_cons=true;cf=ring_hybrid_consumer;break;case M_RING32_FUTEX:has_cons=true;cf=ring_futex_consumer;break;case M_SLAB4_COND:case M_SLAB5_COND:case M_SLAB6_COND:has_cons=true;cf=slab_cond_consumer;break;case M_SLAB4_HYBRID:case M_SLAB5_HYBRID:case M_SLAB6_HYBRID:has_cons=true;cf=slab_hybrid_consumer;break;case M_SLAB4_SPIN:case M_SLAB5_SPIN:case M_SLAB6_SPIN:has_cons=true;cf=slab_spin_consumer;break;case M_SLAB6_CHAIN_ZC:has_cons=true;cf=slab_chain_zc_consumer;break;default:break;}
  if(has_cons)pthread_create(&cons,NULL,cf,&c);uint64_t cpu0=ns_now(CLOCK_PROCESS_CPUTIME_ID),t0=ns_now(CLOCK_MONOTONIC);pthread_create(&recvth,NULL,receiver_thread,&c);pthread_create(&prod,NULL,producer_thread,&c);struct timespec req={dur/1000,(dur%1000)*1000000L};nanosleep(&req,NULL);atomic_store(&c.stop,true);pthread_join(prod,NULL);pthread_join(recvth,NULL);if(has_cons)pthread_join(cons,NULL);uint64_t t1=ns_now(CLOCK_MONOTONIC),cpu1=ns_now(CLOCK_PROCESS_CPUTIME_ID);
  double secs=(t1-t0)/1e9;uint64_t in=atomic_load(&c.input_frames),pub=atomic_load(&c.published_frames),reads=atomic_load(&c.socket_reads),err=atomic_load(&c.validation_errors),ret=atomic_load(&c.retries),wait=atomic_load(&c.waits),wake=atomic_load(&c.wakes);double fps=in/secs,pps=pub/secs,mib=(double)in*frame/1048576.0/secs,skip=in?100.0*(double)(in-(pub>in?in:pub))/in:0,fr=reads?(double)in/reads:0,cpu=in?(double)(cpu1-cpu0)/in:0;
  if(header)puts("mode,frameBytes,workUs,inputFramesPerSec,publishedPerSec,MiBPerSec,skippedPercent,framesPerSocketRead,cpuNsPerInputFrame,retries,waitLoops,wakeCalls,validationErrors");printf("%s,%zu,%d,%.3f,%.3f,%.3f,%.6f,%.3f,%.3f,%llu,%llu,%llu,%llu\n",mode_name(mode),frame,work,fps,pps,mib,skip,fr,cpu,(unsigned long long)ret,(unsigned long long)wait,(unsigned long long)wake,(unsigned long long)err);

  close(c.tx_fd);close(c.rx_fd);free(c.send_slab);free(c.consumer_buf);free(c.seq_slot);
  if(c.pipe_buf){for(int i=0;i<c.pipe_n;i++)free(c.pipe_buf[i]);free(c.pipe_buf);free(c.pipe_len);free(c.pipe_q);free(c.pipe_carry);}if(c.fslots){for(int i=0;i<c.fslot_n;i++)free(c.fslots[i]);free(c.fslots);}if(c.ring_slots){for(int i=0;i<c.ring_n;i++)free(c.ring_slots[i]);free(c.ring_slots);free(c.ring_seq);}if(c.sslabs){for(int i=0;i<c.sslab_n;i++)free(c.sslabs[i]);free(c.sslabs);free(c.sslab_last_off);free(c.s_carry);}pthread_mutex_destroy(&c.pipe_mu);pthread_cond_destroy(&c.pipe_not_empty);pthread_cond_destroy(&c.pipe_not_full);pthread_mutex_destroy(&c.f_mu);pthread_cond_destroy(&c.f_cv);pthread_mutex_destroy(&c.s_mu);pthread_cond_destroy(&c.s_cv);return err?2:0;
}

int main(int argc,char**argv){model_t mode=M_QUAD_CLAIM_COND;size_t frame=32;int dur=800,work=10;bool header=true;for(int i=1;i<argc;i++){if(!strcmp(argv[i],"--mode")&&i+1<argc){if(parse_mode(argv[++i],&mode)){fprintf(stderr,"bad mode\n");return 1;}}else if(!strcmp(argv[i],"--frame")&&i+1<argc)frame=strtoull(argv[++i],0,10);else if(!strcmp(argv[i],"--duration-ms")&&i+1<argc)dur=atoi(argv[++i]);else if(!strcmp(argv[i],"--work-us")&&i+1<argc)work=atoi(argv[++i]);else if(!strcmp(argv[i],"--hybrid-spins")&&i+1<argc){setenv("DHMP_HYBRID_SPINS",argv[++i],1);}else if(!strcmp(argv[i],"--ring-slots")&&i+1<argc){setenv("DHMP_RING_SLOTS",argv[++i],1);}else if(!strcmp(argv[i],"--publish-stride")&&i+1<argc){setenv("DHMP_PUBLISH_STRIDE",argv[++i],1);}else if(!strcmp(argv[i],"--no-header"))header=false;else{fprintf(stderr,"bad arg %s\n",argv[i]);return 1;}}return run_one(mode,frame,dur,work,header);}
