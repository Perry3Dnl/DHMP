#!/usr/bin/env python3
"""Reproducible two-pass screen for selected DHMP Gen-2 processor paths."""
import csv, os, pathlib, subprocess
ROOT=pathlib.Path(__file__).resolve().parent; EXE=ROOT/'gen2_processor_lab'
FRAMES=[16,32,256,1024]; DURATION_MS=800; REPS=2
CASES=[
 ('every-inline-baseline',0,{}),('every-fast4',0,{}),
 ('latest-triple-cond-baseline',10,{}),('latest-ring8-spin',10,{}),
 ('latest-slab5-spin',10,{}),('latest-slab6-hybrid',10,{'DHMP_HYBRID_SPINS':'1024'}),
]
rows=[]
for frame in FRAMES:
  for mode,work,extra in CASES:
    for rep in range(REPS):
      env=os.environ.copy(); env.update(extra)
      cp=subprocess.run([str(EXE),'--mode',mode,'--frame',str(frame),'--duration-ms',str(DURATION_MS),'--work-us',str(work)],env=env,text=True,capture_output=True,check=True,timeout=10)
      lines=[x for x in cp.stdout.splitlines() if x.strip()]; row=dict(zip(lines[0].split(','),lines[1].split(','))); row['rep']=rep; rows.append(row)
out=ROOT/'two-pass-results.csv'
with out.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
print(out)
