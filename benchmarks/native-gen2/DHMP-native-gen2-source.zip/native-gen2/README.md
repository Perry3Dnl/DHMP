# DHMP Gen-2 native processor lab

Experimental Linux/C architecture lab used to explore DHMP receive/processor paths quickly before porting promising ideas back to the .NET prototype.

It is **not** the DHMP production implementation. Absolute throughput from this lab must not be compared directly with Windows/.NET results.

Current assumptions:

- fixed frame contract and no per-frame DHMP header;
- adaptive slab target `clamp(frameSize * 512, 16 KiB, 1 MiB)`;
- reusable fixed memory;
- `Every` processes every complete frame;
- `Latest` may conflate stale complete frames while preserving a stable newest frame.

Build with `make`, then run a mode, for example:

```bash
./gen2_processor_lab --mode latest-ring8-spin --frame 32 --duration-ms 800 --work-us 10
```

The retained published results use two runs per point. Selected points have zero validation errors. See `docs/BENCHMARKS.md` for interpretation and caveats.
