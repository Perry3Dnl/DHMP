#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define MAX_RING 8

typedef enum {
    PATH_RING3,
    PATH_RING8,
    PATH_SLAB6,
    PATH_RAW,
    PATH_LEN4,
    PATH_WS,
    PATH_HTTP,
    PATH_UDP,
    PATH_DHMPS
} path_t;

typedef struct {
    path_t path;
    const char *name;
    size_t frame_size;
    size_t slab_size;
    int ring_capacity;
    double warmup_s;
    double measure_s;
    int listen_fd;
    int sender_fd;
    int receiver_fd;
    struct sockaddr_in addr;
    _Atomic int ready;
    _Atomic int measure;
    _Atomic int stop;
    _Atomic uint64_t input_frames;
    _Atomic uint64_t publish_seq;
    _Atomic uint64_t useful_pubs;
    _Atomic uint64_t socket_ops;
    _Atomic uint64_t validation_errors;
    _Atomic unsigned latest_index;
    uint8_t *ring;
    volatile uint64_t sink;
    SSL_CTX *server_ctx;
    SSL_CTX *client_ctx;
} bench_t;

static double now_s(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
    return (double)t.tv_sec + (double)t.tv_nsec / 1e9;
}

static void *alloc64(size_t bytes) {
    void *p = NULL;
    if (posix_memalign(&p, 64, bytes) != 0) return NULL;
    return p;
}

static void pin_cpu(int cpu) {
#ifdef __linux__
    cpu_set_t set; CPU_ZERO(&set); CPU_SET(cpu, &set);
    pthread_setaffinity_np(pthread_self(), sizeof(set), &set);
#else
    (void)cpu;
#endif
}

static void busy_wait_us(double us) {
    const double end = now_s() + us / 1e6;
    while (now_s() < end) { __asm__ __volatile__("" ::: "memory"); }
}

static int set_timeout_ms(int fd, int ms) {
    struct timeval tv = {.tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000};
    if (setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv))) return -1;
    if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv))) return -1;
    return 0;
}

static void publish_payload(bench_t *b, const uint8_t *payload, unsigned *write_index) {
    unsigned idx = *write_index;
    memcpy(b->ring + (size_t)idx * b->frame_size, payload, b->frame_size);
    atomic_store_explicit(&b->latest_index, idx, memory_order_release);
    atomic_fetch_add_explicit(&b->publish_seq, 1, memory_order_release);
    idx++;
    if (idx == (unsigned)b->ring_capacity) idx = 0;
    *write_index = idx;
}

static void process_fixed(bench_t *b, uint8_t *buf, size_t total, size_t *carry, unsigned *write_index) {
    const size_t f = b->frame_size;
    const size_t complete = total / f;
    const size_t tail = total - complete * f;
    if (complete) {
        if (atomic_load_explicit(&b->measure, memory_order_relaxed))
            atomic_fetch_add_explicit(&b->input_frames, complete, memory_order_relaxed);

        size_t keep = complete < (size_t)b->ring_capacity ? complete : (size_t)b->ring_capacity;
        size_t first = complete - keep;
        unsigned newest = *write_index;
        for (size_t i = 0; i < keep; ++i) {
            unsigned idx = *write_index;
            memcpy(b->ring + (size_t)idx * f, buf + (first + i) * f, f);
            newest = idx;
            idx++;
            if (idx == (unsigned)b->ring_capacity) idx = 0;
            *write_index = idx;
        }
        atomic_store_explicit(&b->latest_index, newest, memory_order_release);
        atomic_fetch_add_explicit(&b->publish_seq, 1, memory_order_release);
    }
    if (tail) memmove(buf, buf + complete * f, tail);
    *carry = tail;
}

static void process_len4(bench_t *b, uint8_t *buf, size_t total, size_t *carry, unsigned *write_index) {
    size_t p = 0, count = 0, last_payload = 0;
    while (total - p >= 4) {
        uint32_t n; memcpy(&n, buf + p, 4); n = ntohl(n);
        if (n != b->frame_size) {
            atomic_fetch_add(&b->validation_errors, 1); break;
        }
        if (total - p < 4u + n) break;
        last_payload = p + 4; count++; p += 4u + n;
    }
    if (count) {
        if (atomic_load(&b->measure)) atomic_fetch_add(&b->input_frames, count);
        publish_payload(b, buf + last_payload, write_index);
    }
    if (p && p < total) memmove(buf, buf + p, total - p);
    *carry = total - p;
}

static void process_ws(bench_t *b, uint8_t *buf, size_t total, size_t *carry, unsigned *write_index) {
    size_t p = 0, count = 0, last_payload = 0;
    while (total - p >= 2) {
        uint8_t b0 = buf[p], b1 = buf[p+1];
        if ((b0 & 0x0f) != 2 || (b1 & 0x80)) { atomic_fetch_add(&b->validation_errors,1); break; }
        uint64_t n = b1 & 0x7f; size_t h = 2;
        if (n == 126) {
            if (total - p < 4) break;
            uint16_t x; memcpy(&x,buf+p+2,2); n = ntohs(x); h = 4;
        } else if (n == 127) {
            atomic_fetch_add(&b->validation_errors,1); break;
        }
        if (n != b->frame_size) { atomic_fetch_add(&b->validation_errors,1); break; }
        if (total - p < h + n) break;
        last_payload = p + h; count++; p += h + (size_t)n;
    }
    if (count) {
        if (atomic_load(&b->measure)) atomic_fetch_add(&b->input_frames, count);
        publish_payload(b, buf + last_payload, write_index);
    }
    if (p && p < total) memmove(buf, buf+p, total-p);
    *carry = total - p;
}

static int hexval(unsigned char c) {
    if (c>='0'&&c<='9') return c-'0';
    if (c>='a'&&c<='f') return c-'a'+10;
    if (c>='A'&&c<='F') return c-'A'+10;
    return -1;
}

static void process_http(bench_t *b, uint8_t *buf, size_t total, size_t *carry, unsigned *write_index) {
    size_t p=0,count=0,last_payload=0;
    while (p<total) {
        size_t q=p; uint64_t n=0; int digits=0;
        while (q<total && buf[q]!='\r') {
            int h=hexval(buf[q]); if(h<0){ atomic_fetch_add(&b->validation_errors,1); goto done; }
            n=(n<<4)|(unsigned)h; digits++; q++;
        }
        if (q+1>=total) break;
        if (!digits || buf[q]!='\r' || buf[q+1]!='\n') { atomic_fetch_add(&b->validation_errors,1); break; }
        if (n != b->frame_size) { atomic_fetch_add(&b->validation_errors,1); break; }
        size_t payload=q+2;
        if (total-payload < n+2) break;
        if (buf[payload+n]!='\r' || buf[payload+n+1]!='\n') { atomic_fetch_add(&b->validation_errors,1); break; }
        last_payload=payload; count++; p=payload+(size_t)n+2;
    }
done:
    if (count) {
        if (atomic_load(&b->measure)) atomic_fetch_add(&b->input_frames,count);
        publish_payload(b,buf+last_payload,write_index);
    }
    if (p && p<total) memmove(buf,buf+p,total-p);
    *carry=total-p;
}

static void *consumer_main(void *arg) {
    bench_t *b=(bench_t*)arg; pin_cpu(2);
    uint64_t seen=atomic_load(&b->publish_seq);
    while (!atomic_load(&b->stop)) {
        uint64_t s=atomic_load_explicit(&b->publish_seq,memory_order_acquire);
        if (s!=seen) {
            unsigned idx=atomic_load_explicit(&b->latest_index,memory_order_acquire);
            uint64_t x=0; size_t take=b->frame_size<8?b->frame_size:8;
            memcpy(&x,b->ring+(size_t)idx*b->frame_size,take);
            b->sink ^= x;
            seen=s;
            if (atomic_load(&b->measure)) atomic_fetch_add(&b->useful_pubs,1);
            busy_wait_us(10.0);
        } else {
            __asm__ __volatile__("pause" ::: "memory");
        }
    }
    return NULL;
}

static void *tls_receiver_main(void *arg) {
    bench_t *b=(bench_t*)arg; pin_cpu(1);
    socklen_t alen=sizeof(b->addr);
    int fd=accept(b->listen_fd,(struct sockaddr*)&b->addr,&alen);
    if(fd<0){perror("accept"); atomic_store(&b->stop,1); return NULL;}
    b->receiver_fd=fd; set_timeout_ms(fd,100);
    SSL *ssl=SSL_new(b->server_ctx); SSL_set_fd(ssl,fd);
    if(SSL_accept(ssl)<=0){ERR_print_errors_fp(stderr); atomic_store(&b->stop,1); SSL_free(ssl); close(fd); return NULL;}
    size_t cap=b->slab_size+b->frame_size+32; uint8_t *buf = alloc64(cap); if (!buf) { atomic_store(&b->stop,1); close(fd); return NULL; }
    size_t carry=0; unsigned wi=0; atomic_store(&b->ready,1);
    while(!atomic_load(&b->stop)){
        int n=SSL_read(ssl,buf+carry,(int)(b->slab_size-carry));
        if(n>0){
            if(atomic_load(&b->measure)) atomic_fetch_add(&b->socket_ops,1);
            process_fixed(b,buf,carry+(size_t)n,&carry,&wi);
        } else {
            int e=SSL_get_error(ssl,n);
            if(e==SSL_ERROR_WANT_READ||e==SSL_ERROR_WANT_WRITE) continue;
            break;
        }
    }
    SSL_shutdown(ssl); SSL_free(ssl); close(fd); free(buf); return NULL;
}

static void *tls_sender_main(void *arg) {
    bench_t *b=(bench_t*)arg; pin_cpu(0);
    int fd=socket(AF_INET,SOCK_STREAM,0); b->sender_fd=fd; set_timeout_ms(fd,100);
    if(connect(fd,(struct sockaddr*)&b->addr,sizeof(b->addr))){perror("connect");atomic_store(&b->stop,1);return NULL;}
    SSL *ssl=SSL_new(b->client_ctx); SSL_set_fd(ssl,fd);
    if(SSL_connect(ssl)<=0){ERR_print_errors_fp(stderr);atomic_store(&b->stop,1);SSL_free(ssl);close(fd);return NULL;}
    size_t cap=1<<20; uint8_t *batch = alloc64(cap); if (!batch) { atomic_store(&b->stop,1); SSL_free(ssl); close(fd); return NULL; }
    size_t len=(cap/b->frame_size)*b->frame_size; memset(batch,0xA5,len);
    while(!atomic_load(&b->ready)&&!atomic_load(&b->stop)){}
    while(!atomic_load(&b->stop)){
        size_t p=0;
        while(p<len&&!atomic_load(&b->stop)){
            int n=SSL_write(ssl,batch+p,(int)(len-p));
            if(n>0)p+=(size_t)n;
            else {int e=SSL_get_error(ssl,n); if(e==SSL_ERROR_WANT_WRITE||e==SSL_ERROR_WANT_READ) continue; atomic_store(&b->stop,1);break;}
        }
    }
    SSL_shutdown(ssl); SSL_free(ssl); close(fd); free(batch); return NULL;
}

static void *stream_receiver_main(void *arg) {
    bench_t *b=(bench_t*)arg; pin_cpu(1);
    socklen_t alen=sizeof(b->addr);
    int fd=accept(b->listen_fd,(struct sockaddr*)&b->addr,&alen);
    if(fd<0){perror("accept"); atomic_store(&b->stop,1); return NULL;}
    b->receiver_fd=fd; set_timeout_ms(fd,100);
    size_t cap=b->slab_size + b->frame_size + 32;
    uint8_t *buf = alloc64(cap); if (!buf) { atomic_store(&b->stop,1); close(fd); return NULL; }
    size_t carry=0; unsigned wi=0;
    atomic_store(&b->ready,1);
    while(!atomic_load(&b->stop)) {
        ssize_t n=recv(fd,buf+carry,b->slab_size-carry,0);
        if(n>0){
            if(atomic_load(&b->measure)) atomic_fetch_add(&b->socket_ops,1);
            size_t total=carry+(size_t)n;
            switch(b->path){
                case PATH_RING3: case PATH_RING8: case PATH_SLAB6: case PATH_RAW:
                    process_fixed(b,buf,total,&carry,&wi); break;
                case PATH_LEN4: process_len4(b,buf,total,&carry,&wi); break;
                case PATH_WS: process_ws(b,buf,total,&carry,&wi); break;
                case PATH_HTTP: process_http(b,buf,total,&carry,&wi); break;
                default: break;
            }
        } else if(n==0) break;
        else if(errno!=EAGAIN && errno!=EWOULDBLOCK && errno!=EINTR) break;
    }
    close(fd); free(buf); return NULL;
}

static size_t build_batch(bench_t *b, uint8_t *out, size_t cap) {
    size_t p=0; const size_t f=b->frame_size;
    uint8_t payload[2048]; if(f>sizeof(payload)) return 0;
    memset(payload,0xA5,f);
    if (f>=8) { uint64_t marker=0x1122334455667788ULL; memcpy(payload,&marker,8); }
    while(1){
        if(b->path==PATH_RING3||b->path==PATH_RING8||b->path==PATH_SLAB6||b->path==PATH_RAW){
            if (cap - p < f) break;
            memcpy(out + p, payload, f);
            p += f;
        } else if(b->path==PATH_LEN4){
            if (cap - p < 4 + f) break;
            uint32_t n = htonl((uint32_t)f);
            memcpy(out + p, &n, 4);
            memcpy(out + p + 4, payload, f);
            p += 4 + f;
        } else if(b->path==PATH_WS){
            size_t h=f<126?2:4; if(cap-p<h+f) break;
            out[p]=0x82; if(f<126){out[p+1]=(uint8_t)f;} else {out[p+1]=126; uint16_t n=htons((uint16_t)f); memcpy(out+p+2,&n,2);} memcpy(out+p+h,payload,f); p+=h+f;
        } else if(b->path==PATH_HTTP){
            char hex[32]; int h=snprintf(hex,sizeof(hex),"%zx\r\n",f); size_t need=(size_t)h+f+2; if(cap-p<need)break;
            memcpy(out+p,hex,(size_t)h); memcpy(out+p+h,payload,f); out[p+h+f]='\r'; out[p+h+f+1]='\n'; p+=need;
        } else break;
    }
    return p;
}

static void *stream_sender_main(void *arg) {
    bench_t *b=(bench_t*)arg; pin_cpu(0);
    int fd=socket(AF_INET,SOCK_STREAM,0); b->sender_fd=fd; set_timeout_ms(fd,100);
    if(connect(fd,(struct sockaddr*)&b->addr,sizeof(b->addr))){perror("connect");atomic_store(&b->stop,1);return NULL;}
    size_t cap=1<<20; uint8_t *batch = alloc64(cap); if (!batch) { atomic_store(&b->stop,1); close(fd); return NULL; }
    size_t len=build_batch(b,batch,cap);
    while(!atomic_load(&b->ready)&&!atomic_load(&b->stop)){}
    while(!atomic_load(&b->stop)){
        size_t p=0;
        while(p<len&&!atomic_load(&b->stop)){
            ssize_t n=send(fd,batch+p,len-p,MSG_NOSIGNAL);
            if(n>0)p+=(size_t)n;
            else if(n<0&&(errno==EINTR||errno==EAGAIN||errno==EWOULDBLOCK)) continue;
            else {atomic_store(&b->stop,1);break;}
        }
    }
    shutdown(fd,SHUT_RDWR); close(fd); free(batch); return NULL;
}

static void *udp_receiver_main(void *arg) {
    bench_t *b=(bench_t*)arg; pin_cpu(1);
    int fd=socket(AF_INET,SOCK_DGRAM,0); b->receiver_fd=fd; set_timeout_ms(fd,100);
    if(bind(fd,(struct sockaddr*)&b->addr,sizeof(b->addr))){perror("udp bind");atomic_store(&b->stop,1);return NULL;}
    uint8_t *buf = alloc64(b->frame_size); if (!buf) { atomic_store(&b->stop,1); close(fd); return NULL; }
    unsigned wi=0; atomic_store(&b->ready,1);
    while(!atomic_load(&b->stop)){
        ssize_t n=recv(fd,buf,b->frame_size,0);
        if(n==(ssize_t)b->frame_size){
            if(atomic_load(&b->measure)){atomic_fetch_add(&b->input_frames,1);atomic_fetch_add(&b->socket_ops,1);} publish_payload(b,buf,&wi);
        } else if(n<0&&(errno==EAGAIN||errno==EWOULDBLOCK||errno==EINTR)) continue;
        else if(n<0) break;
        else atomic_fetch_add(&b->validation_errors,1);
    }
    close(fd); free(buf); return NULL;
}

static void *udp_sender_main(void *arg){
    bench_t *b=(bench_t*)arg; pin_cpu(0);
    while(!atomic_load(&b->ready)&&!atomic_load(&b->stop)){}
    int fd=socket(AF_INET,SOCK_DGRAM,0); b->sender_fd=fd; set_timeout_ms(fd,100);
    uint8_t *buf = alloc64(b->frame_size); if (!buf) { atomic_store(&b->stop,1); close(fd); return NULL; } memset(buf,0xA5,b->frame_size);
    while(!atomic_load(&b->stop)){
        ssize_t n=sendto(fd,buf,b->frame_size,0,(struct sockaddr*)&b->addr,sizeof(b->addr));
        if(n<0&&errno!=EINTR&&errno!=EAGAIN&&errno!=EWOULDBLOCK){atomic_store(&b->stop,1);break;}
    }
    close(fd); free(buf); return NULL;
}

static int path_from(const char *s,path_t *p,int *ring,const char **name){
    if(!strcmp(s,"ring3")){*p=PATH_RING3;*ring=3;*name="DHMP Ring3 Fixed-Slab";}
    else if(!strcmp(s,"ring8")){*p=PATH_RING8;*ring=8;*name="DHMP Ring8";}
    else if(!strcmp(s,"slab6")){*p=PATH_SLAB6;*ring=6;*name="DHMP Slab6";}
    else if(!strcmp(s,"raw")){*p=PATH_RAW;*ring=2;*name="Raw TCP fixed";}
    else if(!strcmp(s,"len4")){*p=PATH_LEN4;*ring=2;*name="TCP + 4B length";}
    else if(!strcmp(s,"ws")){*p=PATH_WS;*ring=2;*name="WebSocket framing";}
    else if(!strcmp(s,"http")){*p=PATH_HTTP;*ring=2;*name="HTTP chunk framing";}
    else if(!strcmp(s,"udp")){*p=PATH_UDP;*ring=2;*name="UDP datagram";}
    else if(!strcmp(s,"dhmps")){*p=PATH_DHMPS;*ring=3;*name="DHMPS TLS Ring3";}
    else return -1;
    return 0;
}

int main(int argc,char **argv){
    signal(SIGPIPE,SIG_IGN);
    if(argc<3){fprintf(stderr,"usage: %s PATH FRAME_BYTES [WARMUP=0.5] [MEASURE=1.5] [SLAB=12288]\n",argv[0]);return 2;}
    bench_t b={0};
    if(path_from(argv[1],&b.path,&b.ring_capacity,&b.name)){fprintf(stderr,"unknown path\n");return 2;}
    b.frame_size=strtoull(argv[2],0,10); b.warmup_s=argc>3?atof(argv[3]):0.5; b.measure_s=argc>4?atof(argv[4]):1.5; b.slab_size=argc>5?strtoull(argv[5],0,10):12288;
    if(b.frame_size<1||b.frame_size>2048||b.slab_size<b.frame_size){fprintf(stderr,"invalid args\n");return 2;}
    b.slab_size-=b.slab_size%b.frame_size; if(!b.slab_size)b.slab_size=b.frame_size;
    b.ring = alloc64((size_t)b.ring_capacity * b.frame_size);
    if (!b.ring) return 1;
    memset(b.ring, 0, (size_t)b.ring_capacity * b.frame_size);

    pthread_t rx,tx,consumer;
    if(b.path==PATH_DHMPS){
        if(argc<8){fprintf(stderr,"dhmps requires CERT KEY as argv[6] argv[7]\n");return 2;}
        SSL_library_init(); SSL_load_error_strings();
        b.server_ctx=SSL_CTX_new(TLS_server_method()); b.client_ctx=SSL_CTX_new(TLS_client_method());
        SSL_CTX_set_min_proto_version(b.server_ctx,TLS1_3_VERSION); SSL_CTX_set_min_proto_version(b.client_ctx,TLS1_3_VERSION);
        SSL_CTX_set_verify(b.client_ctx,SSL_VERIFY_NONE,NULL);
        if(SSL_CTX_use_certificate_file(b.server_ctx,argv[6],SSL_FILETYPE_PEM)!=1 || SSL_CTX_use_PrivateKey_file(b.server_ctx,argv[7],SSL_FILETYPE_PEM)!=1){ERR_print_errors_fp(stderr);return 1;}
        b.listen_fd=socket(AF_INET,SOCK_STREAM,0); int one=1; setsockopt(b.listen_fd,SOL_SOCKET,SO_REUSEADDR,&one,sizeof(one));
        struct sockaddr_in a={0};a.sin_family=AF_INET;a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);a.sin_port=0; bind(b.listen_fd,(struct sockaddr*)&a,sizeof(a)); listen(b.listen_fd,1); socklen_t alen=sizeof(a); getsockname(b.listen_fd,(struct sockaddr*)&a,&alen); b.addr=a;
        pthread_create(&rx,0,tls_receiver_main,&b); pthread_create(&tx,0,tls_sender_main,&b);
    } else if(b.path==PATH_UDP){
        int tmp=socket(AF_INET,SOCK_DGRAM,0); struct sockaddr_in a={0}; a.sin_family=AF_INET;a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);a.sin_port=0; bind(tmp,(struct sockaddr*)&a,sizeof(a)); socklen_t alen=sizeof(a); getsockname(tmp,(struct sockaddr*)&a,&alen); close(tmp); b.addr=a;
        pthread_create(&rx,0,udp_receiver_main,&b); pthread_create(&tx,0,udp_sender_main,&b);
    } else {
        b.listen_fd=socket(AF_INET,SOCK_STREAM,0); int one=1; setsockopt(b.listen_fd,SOL_SOCKET,SO_REUSEADDR,&one,sizeof(one));
        struct sockaddr_in a={0};a.sin_family=AF_INET;a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);a.sin_port=0; bind(b.listen_fd,(struct sockaddr*)&a,sizeof(a)); listen(b.listen_fd,1); socklen_t alen=sizeof(a); getsockname(b.listen_fd,(struct sockaddr*)&a,&alen); b.addr=a;
        pthread_create(&rx,0,stream_receiver_main,&b); pthread_create(&tx,0,stream_sender_main,&b);
    }
    pthread_create(&consumer,0,consumer_main,&b);
    while(!atomic_load(&b.ready)&&!atomic_load(&b.stop)){}
    usleep((useconds_t)(b.warmup_s*1e6));
    atomic_store(&b.input_frames,0); atomic_store(&b.useful_pubs,0); atomic_store(&b.socket_ops,0); atomic_store(&b.validation_errors,0); atomic_store(&b.measure,1);
    double t0=now_s(); usleep((useconds_t)(b.measure_s*1e6)); double t1=now_s(); atomic_store(&b.measure,0); atomic_store(&b.stop,1);
    if (b.sender_fd > 0) shutdown(b.sender_fd, SHUT_RDWR);
    if (b.receiver_fd > 0) shutdown(b.receiver_fd, SHUT_RDWR);
    if (b.listen_fd > 0) close(b.listen_fd);
    pthread_join(tx,0); pthread_join(rx,0); pthread_join(consumer,0);
    double dt=t1-t0; uint64_t in=atomic_load(&b.input_frames),pub=atomic_load(&b.useful_pubs),ops=atomic_load(&b.socket_ops),errs=atomic_load(&b.validation_errors);
    printf("path=%s,frame=%zu,seconds=%.6f,input_fps=%.3f,published_fps=%.3f,payload_GBps=%.6f,socket_ops_s=%.3f,ring_slots=%d,ring_bytes=%zu,slab_bytes=%zu,errors=%llu,sink=%llu\n",
        argv[1],b.frame_size,dt,in/dt,pub/dt,(in/dt)*(double)b.frame_size/1e9,ops/dt,b.ring_capacity,(size_t)b.ring_capacity*b.frame_size,b.slab_size,(unsigned long long)errs,(unsigned long long)b.sink);
    if (b.server_ctx) SSL_CTX_free(b.server_ctx);
    if (b.client_ctx) SSL_CTX_free(b.client_ctx);
    free(b.ring);
    return errs ? 3 : 0;
}
