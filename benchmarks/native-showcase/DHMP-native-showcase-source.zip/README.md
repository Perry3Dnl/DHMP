# DHMP native showcase v2 source

This archive contains the current native 32-byte streaming showcase harness.

`showcase_v2.c` integrates `DHMP Ring-3 Fixed-Slab Latest` directly into the same executable and timing model as Ring8, Slab6, DHMPS/TLS, raw fixed TCP, 4-byte length-prefixed TCP, WebSocket binary framing, HTTP/1.1 chunk framing, and UDP datagrams.

Build:

```bash
make
```

Example Ring-3 run:

```bash
./showcase_v2 ring3 32 0.5 1.5 12288
```

DHMPS requires a PEM certificate and key as the final two arguments.

The retained repository run uses 32-byte logical frames, 12 KiB fixed receive workspace, 0.5 s warmup, 1.5 s measurement, 10 us simulated consumer work, and three deterministic path-order passes. See `docs/BENCHMARKS.md` for result interpretation.
